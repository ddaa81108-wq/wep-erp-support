import { webPushMigrations } from './migrationsWebPush.ts';
import { reportClosingMigrations } from './migrationsReportClosing.ts';
import { securityMigrations } from './migrationsSecurity.ts';
import type { Migration } from './migrationTypes.ts';
import { foundationMigrations } from './migrationsFoundation.ts';
import { organizationMigrations } from './migrationsOrganization.ts';
import { financialMigrations } from './migrationsFinancial.ts';
import { reportMigrations } from './migrationsReports.ts';
import { settingsMigrations } from './migrationsSettings.ts';
import { payrollMigrations } from './migrationsPayroll.ts';
import { masraweyaCorrectionMigrations } from './migrationsMasraweyaCorrection.ts';

import { reliabilityMigrations } from './migrationsReliability.ts';
import { masraweyaAutomaticMigrations } from './migrationsMasraweyaAutomatic.ts';
import { collectionRejectionMigrations } from './migrationsCollectionRejection.ts';
import { zeroReviewMigrations } from './migrationsZeroReview.ts';
import { collectionInstallmentMigrations } from './migrationsCollectionInstallments.ts';
import { unlinkedCurrencyMigrations } from './migrationsUnlinkedCurrency.ts';
import { notificationSpeechMigrations } from './migrationsNotificationSpeech.ts';
import { collectionAssignedAmountMigrations } from './migrationsCollectionAssignedAmount.ts';
import { collectionSubmissionBalanceMigrations } from './migrationsCollectionSubmissionBalance.ts';
import { collectionRejectedBalanceMigrations } from './migrationsCollectionRejectedBalance.ts';
import { sectionZeroReviewMigrations } from './migrationsSectionZeroReview.ts';

export type { Migration } from './migrationTypes.ts';

export const migrations: Migration[] = [
  ...foundationMigrations,
  ...organizationMigrations,
  ...financialMigrations,
  ...reportMigrations,
  ...settingsMigrations,
  ...payrollMigrations,
  ...masraweyaCorrectionMigrations,
  ...reliabilityMigrations,
  ...masraweyaAutomaticMigrations,
  ...zeroReviewMigrations,
  ...collectionRejectionMigrations,
  ...webPushMigrations,
  ...reportClosingMigrations,
  ...securityMigrations,
  ...collectionInstallmentMigrations,
  ...unlinkedCurrencyMigrations,
  ...notificationSpeechMigrations,
  ...collectionAssignedAmountMigrations,
  ...collectionSubmissionBalanceMigrations,
  ...collectionRejectedBalanceMigrations,
  ...sectionZeroReviewMigrations,
];
